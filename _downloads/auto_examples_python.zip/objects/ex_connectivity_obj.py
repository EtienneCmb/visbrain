"""
Connectivity object
===================

Futur title
"""
from visbrain.objects import ConnectObj, SceneObj
